-- 1 Quelles sont les commandes du fournisseur 09120 ?

SELECT NUMCOM, DATCOM, OBSCOM
FROM ENTCOM
WHERE NUMFOU = '09120';