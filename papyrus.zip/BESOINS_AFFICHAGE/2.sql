-- 2. Afficher le code des fournisseurs pour lesquels des commandes ont été passées.

SELECT DISTINCT NUMFOU
FROM ENTCOM;